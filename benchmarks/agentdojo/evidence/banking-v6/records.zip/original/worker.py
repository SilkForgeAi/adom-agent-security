"""Shared stock AgentDojo episode runner; frozen authority, explicit error classification."""
import os,sys,json,sqlite3,time,hashlib,multiprocessing,statistics
from pathlib import Path
os.environ.setdefault('ADOM_AGENTDOJO_SUITE','banking')
ROOT=Path(__file__).resolve().parent;SOURCE=ROOT/'source';MODEL='gpt-4o-2024-05-13';OUT=Path(os.environ.get('ADOM_EVAL_OUT',str(ROOT/'results'/os.environ['ADOM_AGENTDOJO_SUITE'])))
sys.path.insert(0,str(SOURCE))
def load_key():
 if not os.environ.get('OPENAI_API_KEY'):raise RuntimeError('Set OPENAI_API_KEY in the environment; credentials are never bundled.')
 os.environ['ADOM_AGENTDOJO_OUT']=str(OUT)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def usage():
 with sqlite3.connect(OUT/'usage.sqlite',timeout=30) as db:
  r=db.execute('SELECT calls,prompt,completion FROM usage').fetchone()
 return {'api_calls':r[0],'prompt_tokens':r[1],'completion_tokens':r[2],'estimated_usd':(r[1]*5.0+r[2]*15.0)/1000000}
def budget_reserve(amount):
 with sqlite3.connect(os.environ['ADOM_GLOBAL_BUDGET_DB'],timeout=30) as db:
  db.execute('BEGIN IMMEDIATE')
  total=db.execute('SELECT COALESCE(SUM(COALESCE(actual,reserved)),0) FROM reservations').fetchone()[0]
  if total+amount>float(os.environ['ADOM_GLOBAL_COST_LIMIT']):raise RuntimeError('global estimated spend reservation ceiling reached')
  c=db.execute('INSERT INTO reservations(suite,reserved,status) VALUES(?,?,?)',(os.environ['ADOM_AGENTDOJO_SUITE'],amount,'IN_FLIGHT'));db.commit();return c.lastrowid

def budget_finish(token,actual):
 with sqlite3.connect(os.environ['ADOM_GLOBAL_BUDGET_DB'],timeout=30) as db:db.execute('UPDATE reservations SET actual=?,status=? WHERE id=?',(actual,'RETURNED' if actual is not None else 'UNKNOWN_BILLING',token))

def init_worker():
 global run,suite,policies,by_prompt,CURRENT,OUTCOMES,DENIALS
 load_key()
 from adom.evaluation.agentdojo import run as run_module
 from agentdojo.functions_runtime import FunctionsRuntime
 from adom.evaluation.agentdojo.executor import AdomToolsExecutor
 from openai.resources.chat.completions import Completions
 from openai.resources.responses import Responses
 run=run_module;suite,policies=run._load_suite_and_policies();by_prompt={suite.user_tasks[t].PROMPT:p for t,p in policies.items()};CURRENT={};OUTCOMES=[];DENIALS=[]
 original=Completions.create
 def tracked(self,*a,**kw):
  with sqlite3.connect(OUT/'usage.sqlite',timeout=30) as db:
   db.execute('BEGIN IMMEDIATE');calls,prompt,completion=db.execute('SELECT calls,prompt,completion FROM usage').fetchone()
   if calls>=20000 or (prompt*5.0+completion*15.0)/1000000>=float(os.environ.get('ADOM_EVAL_COST_LIMIT','30' if os.environ['ADOM_AGENTDOJO_SUITE']=='workspace' else '12')):raise RuntimeError('registered request/spend ceiling reached')
   db.execute('UPDATE usage SET calls=calls+1');db.commit()
  # Cross-suite budget: reserve a conservative serialized-input plus full output-cap estimate before dispatch.
  reserve=(len(json.dumps(kw,default=str).encode('utf-8'))+1024)*5.0/1000000+4096*15.0/1000000
  token=budget_reserve(reserve)
  kw['store']=False
  from openai._constants import DEFAULT_TIMEOUT
  self._client.timeout=DEFAULT_TIMEOUT;self._client.max_retries=0
  try:r=original(self,*a,**kw)
  except BaseException:
   budget_finish(token,None);raise
  actual=((getattr(r.usage,'prompt_tokens',getattr(r.usage,'input_tokens',0))*5.0+getattr(r.usage,'completion_tokens',getattr(r.usage,'output_tokens',0))*15.0)/1000000) if r.usage else None
  if getattr(r,'model',MODEL)!=MODEL: budget_finish(token,actual);raise RuntimeError('returned model mismatch')
  budget_finish(token,actual)
  if r.usage:
   with sqlite3.connect(OUT/'usage.sqlite',timeout=30) as db:db.execute('UPDATE usage SET prompt=prompt+?,completion=completion+?',(getattr(r.usage,"prompt_tokens",getattr(r.usage,"input_tokens",0)),getattr(r.usage,"completion_tokens",getattr(r.usage,"output_tokens",0))))
  return r
 Completions.create=tracked
 original_response=Responses.create
 def response_tracked(self,*a,**kw):
  nonlocal original
  saved=original;original=original_response
  try:return tracked(self,*a,**kw)
  finally:original=saved
 Responses.create=response_tracked
 original_fn=FunctionsRuntime.run_function
 def fn(self,env,name,args,*a,**kw):
  row={'tool':name,'args':args}
  try:
   result,error=original_fn(self,env,name,args,*a,**kw);row.update(outcome='ERROR' if error else 'RETURNED',error=str(error) if error else None);return result,error
  except Exception as e:row.update(outcome='EXCEPTION',exception_type=type(e).__name__);raise
  finally:OUTCOMES.append(row)
 FunctionsRuntime.run_function=fn
 original_screen=AdomToolsExecutor.screen
 def screen(self,name,args):
  ok,reason=original_screen(self,name,args)
  if not ok:DENIALS.append({'tool':name,'args':args,'reason':reason})
  return ok,reason
 AdomToolsExecutor.screen=screen

def episode(job):
 from agentdojo.logging import OutputLogger
 from agentdojo.benchmark import run_task_without_injection_tasks,run_task_with_injection_tasks
 from agentdojo.attacks import load_attack
 CURRENT.clear();CURRENT.update(job);OUTCOMES.clear();DENIALS.clear();start=time.monotonic();record={**job};logdir=OUT/'logs'/job['phase']/f"r{job['repeat']}-{job['condition']}"
 try:
  run._validate_run(run._paths(MODEL));pipeline=run.build_pipeline(MODEL,job['condition'],by_prompt)
  with OutputLogger(str(logdir)):
   if job['phase']=='clean':
    utility,_=run_task_without_injection_tasks(suite,pipeline,suite.user_tasks[job['task']],logdir,True,'v1.2.2');attack_name='none';inj='none';record['utility']=utility
   else:
    attack_name=job['attack'];inj=job['injection_task'];attack=load_attack(attack_name,suite,pipeline)
    u,s=run_task_with_injection_tasks(suite,pipeline,suite.user_tasks[job['task']],attack,logdir,True,[inj],'v1.2.2');record.update(utility=u[(job['task'],inj)],attack_success_raw=s[(job['task'],inj)])
  trace=logdir/pipeline.name/os.environ['ADOM_AGENTDOJO_SUITE']/job['task']/attack_name/(inj+'.json');record['trace_error']=json.loads(trace.read_text()).get('error');record['status']='VALID' if not record['trace_error'] else 'INCONCLUSIVE'
 except Exception as e:
  b=getattr(e,'body',{}) or {}
  if isinstance(b,dict) and isinstance(b.get('error'),dict):b=b['error']
  record['api_error_code']=b.get('code') if isinstance(b,dict) else None
  record['api_error_type']=b.get('type') if isinstance(b,dict) else None
  record.update(status='INCONCLUSIVE',exception_type=type(e).__name__,http_status=getattr(e,'status_code',None),error_param=(getattr(e,'body',{}) or {}).get('param') if isinstance(getattr(e,'body',{}),dict) else None)
 record['adapter_audit']=getattr(getattr(pipeline,'adom_executor',None),'audit',[]) if 'pipeline' in locals() else []
 record.update(duration_s=time.monotonic()-start,denials=list(DENIALS),execution_outcomes=list(OUTCOMES));target=OUT/'episodes'/(job['id']+'.json');target.write_text(json.dumps(record,indent=2));return record
