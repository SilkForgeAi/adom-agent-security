from pathlib import Path
import json,hashlib,sqlite3,collections,datetime
root=Path(__file__).parent
registration=json.loads((root/'registration.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
issues=[]
funded=json.loads((root/'funded-continuation.json').read_text()) if (root/'funded-continuation.json').exists() else {}
for name,digest in funded.get('valid_episode_sha256',{}).items():
 if sha(root/name)!=digest:issues.append('Funded continuation changed a valid result: '+name)
if funded and sha(root/'resume_funded.py')!=funded['launcher_sha256']:issues.append('Funded continuation launcher changed')
for continuation in root.glob('funded-continuation-v2.json'):
 extra=json.loads(continuation.read_text())
 for name,digest in extra['valid_episode_sha256'].items():
  if sha(root/name)!=digest:issues.append('Second funding continuation changed valid result: '+name)
 if sha(root/'resume_full_v2.py')!=extra['launcher_sha256']:issues.append('Second continuation launcher changed')
for continuation in root.glob('funded-continuation-v3.json'):
 extra=json.loads(continuation.read_text())
 for name,digest in extra['valid_episode_sha256'].items():
  if sha(root/name)!=digest:issues.append('Third funding continuation changed valid result: '+name)
 if sha(root/'resume_full_v3.py')!=extra['launcher_sha256']:issues.append('Third continuation launcher changed')
if (root/'pending-funding-v3.json').exists():
 pending=json.loads((root/'pending-funding-v3.json').read_text())
 if sha(root/'funding_resume_v3.py')!=pending['controller_sha256']:issues.append('Funding extension controller changed')
for continuation in root.glob('funded-continuation-v4.json'):
 extra=json.loads(continuation.read_text())
 for name,digest in extra['valid_episode_sha256'].items():
  if sha(root/name)!=digest:issues.append('Fourth funding continuation changed valid result: '+name)
 if sha(root/'resume_full_v4.py')!=extra['launcher_sha256']:issues.append('Fourth continuation launcher changed')
for name,digest in registration.get('imported_valid_episode_hashes',{}).items():
 if sha(root/name)!=digest:issues.append('Imported valid result changed: '+name)
for name,digest in registration['harness_files'].items():
 if sha(root/name)!=digest:issues.append('Harness changed: '+name)
for name,digest in registration['source_files'].items():
 if sha(root/'source'/name)!=digest:issues.append('Source changed: '+name)
records=[];tables={}
for suite in ['banking','travel','slack','workspace']:
 out=root/'results'/suite
 protocol=json.loads((out/'protocol.json').read_text())
 if protocol['registration_sha256']!=sha(root/'registration.json'):issues.append('Registration mismatch: '+suite)
 if protocol['source_files']!=registration['source_files']:issues.append('Protocol source mismatch: '+suite)
 if protocol['worker_sha256']!=sha(root/'worker.py') or protocol['runner_sha256']!=sha(root/'full_suite.py'):issues.append('Harness changed: '+suite)
 freeze=json.loads((out/suite/'policies.json').read_text());saved=freeze.pop('freeze_sha256')
 calculated=hashlib.sha256(json.dumps(freeze,sort_keys=True).encode()).hexdigest()
 if calculated!=saved or saved!=protocol['freeze_sha256']:issues.append('Policy freeze mismatch: '+suite)
 rows=[json.loads(p.read_text()) for p in sorted((out/'episodes').glob('*.json'))]
 ids=[r['id'] for r in rows]
 if len(ids)!=len(set(ids)):issues.append('Duplicate episode: '+suite)
 expected=set()
 for condition in ['baseline','adom']:
  for phase in ['clean','attack']:
   for task in protocol['task_ids']:
    for inj in (protocol['injection_ids'] if phase=='attack' else [None]):
     expected.add(f'{phase}-r1-{condition}-'+('important_instructions' if inj else 'none')+f'-{task}-{inj or "none"}')
 unexpected=set(ids)-expected
 if unexpected:issues.append('Unexpected episodes: '+suite)
 table={}
 for condition in ['baseline','adom']:
  table[condition]={}
  for phase in ['clean','attack']:
   selected=[r for r in rows if r['condition']==condition and r['phase']==phase]
   valid=[r for r in selected if r['status']=='VALID']
   table[condition][phase]={'completed':len(selected),'valid':len(valid),'utility_successes':sum(bool(r.get('utility')) for r in valid),'raw_attack_successes':sum(bool(r.get('attack_success_raw')) for r in valid) if phase=='attack' else None}
 for r in rows:
  trace=out/'logs'/r['phase']/f"r{r['repeat']}-{r['condition']}"/(registration['model']+('-adom' if r['condition']=='adom' else '-baseline'))/suite/r['task']/(r.get('attack') or 'none')/((r.get('injection_task') or 'none')+'.json')
  # Locate native trace without assuming the pipeline's baseline suffix.
  matches=list((out/'logs'/r['phase']/f"r{r['repeat']}-{r['condition']}").glob(f"*/{suite}/{r['task']}/{r.get('attack') or 'none'}/{r.get('injection_task') or 'none'}.json"))
  if len(matches)!=1:issues.append('Native trace missing or ambiguous: '+r['id']);continue
  native=json.loads(matches[0].read_text())
  if r['status']=='VALID' and native.get('error'):issues.append('Valid episode has trace error: '+r['id'])
  # Native score keys differ by phase; preserve unchanged native files regardless.
  for key,recordkey in [('utility','utility'),('security','attack_success_raw')]:
   if key in native and recordkey in r and native[key]!=r[recordkey]:issues.append('Native score mismatch: '+r['id'])
 records.extend(dict(suite=suite,**r) for r in rows)
 table['missing']=sorted(expected-set(ids));tables[suite]=table
with sqlite3.connect(root/'budget.sqlite') as db:
 requests=db.execute('SELECT count(*),COALESCE(SUM(COALESCE(actual,reserved)),0) FROM reservations').fetchone()
 unresolved=db.execute("SELECT count(*) FROM reservations WHERE status!='RETURNED'").fetchone()[0]
report={'preserved_budget_inconclusive_attempts':len(list((root/'budget-continuations').glob('**/episode.json'))),'preserved_funding_inconclusive_attempts':len(list((root/'funding-attempts').glob('**/episode.json'))),'evaluation_class':registration.get('evaluation_class'),'clean_gate_passed':all(g['passed'] for g in json.loads((root/'clean_gate.json').read_text()).values()),'preserved_prior_inconclusive_attempts':len(list((root/'prior-attempts').glob('**/episodes/*.json'))),'preserved_transport_retry_attempts':len(list((root/'transport-attempts').glob('**/episode.json'))) if (root/'transport-attempts').exists() else 0,'audited_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'planned_episodes':registration['planned_episodes'],'completed_episodes':len(records),'valid_episodes':sum(r['status']=='VALID' for r in records),'issues':issues,'tables':tables,'api_requests':requests[0],'estimated_usd':requests[1],'unresolved_requests':unresolved,'qualification':'Full fixed-family matrix planned, one repeat, historically exposed cases and privileged snapshots. Native scores preserved; no adaptive attack or independent reproduction.'}
(root/'audit.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
