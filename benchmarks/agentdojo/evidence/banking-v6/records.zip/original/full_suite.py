import sys,os,json,sqlite3,hashlib,datetime,time,shutil
from pathlib import Path
import worker as m
root=Path(__file__).parent;m.load_key()
from adom.evaluation.agentdojo import run
from importlib.metadata import version
suite,policies=run._load_suite_and_policies();tasks=sorted(suite.user_tasks);injs=sorted(suite.injection_tasks)
digest=lambda x:hashlib.sha256(json.dumps(x,sort_keys=True).encode()).hexdigest()
if sys.argv[1]=='prepare':
 m.OUT.mkdir(parents=True);(m.OUT/'episodes').mkdir()
 with sqlite3.connect(m.OUT/'usage.sqlite') as db:db.execute('CREATE TABLE usage(calls INTEGER,prompt INTEGER,completion INTEGER)');db.execute('INSERT INTO usage VALUES(0,0,0)')
 freeze={'suite':os.environ['ADOM_AGENTDOJO_SUITE'],'benchmark_version':'v1.2.2','agentdojo_version':version('agentdojo'),'adapter_code_sha256':run._code_sha256(),'source':'Developed policies; historical exposure and privileged clean snapshots disclosed. No edits during run.','tasks':{id:p.public_record() for id,p in policies.items()}}
 freeze['freeze_sha256']=digest(freeze)
 (m.OUT/os.environ['ADOM_AGENTDOJO_SUITE']).mkdir();(m.OUT/os.environ['ADOM_AGENTDOJO_SUITE']/'policies.json').write_text(json.dumps(freeze,indent=2))
 protocol={'registered_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'registration_sha256':m.sha(root/'registration.json'),'model':m.MODEL,'agentdojo':version('agentdojo'),'benchmark':'v1.2.2','suite':os.environ['ADOM_AGENTDOJO_SUITE'],'freeze_sha256':freeze['freeze_sha256'],'task_ids':tasks,'injection_ids':injs,'source_files':{str(p.relative_to(m.SOURCE)):m.sha(p) for p in m.SOURCE.rglob('*.py') if '__pycache__' not in p.parts},'worker_sha256':m.sha(root/'worker.py'),'runner_sha256':m.sha(Path(__file__)),'attack':'important_instructions','repeat':1,'planned_clean':2*len(tasks),'planned_attack':2*len(tasks)*len(injs),'baseline_first':True,'no_policy_edits':True,'scoring':'Native scores unchanged. Errors inconclusive, no failed-case exclusions.'}
 protocol['protocol_sha256']=digest(protocol);(m.OUT/'protocol.json').write_text(json.dumps(protocol,indent=2));print(protocol['suite'],'prepared',len(tasks),'tasks',len(injs),'injections',flush=True);raise SystemExit(0)
m.init_worker();phase=sys.argv[1];condition=sys.argv[2]
for task in tasks:
 for inj in (injs if phase=='attack' else [None]):
  job={'id':f'{phase}-r1-{condition}-'+('important_instructions' if inj else 'none')+f'-{task}-{inj or "none"}','phase':phase,'repeat':1,'condition':condition,'task':task,**({'attack':'important_instructions','injection_task':inj} if inj else {})}
  if (m.OUT/'episodes'/(job['id']+'.json')).exists():
   existing=json.loads((m.OUT/'episodes'/(job['id']+'.json')).read_text())
   if existing['status']!='VALID':raise SystemExit('Existing inconclusive episode; no automatic rerun')
   print('PRESERVED',job['id'],flush=True);continue
  for attempt in [1,2]:
   result=m.episode(job)
   print(json.dumps({'suite':os.environ['ADOM_AGENTDOJO_SUITE'],'attempt':attempt,**{k:result.get(k) for k in ['id','status','utility','attack_success_raw','exception_type','http_status','api_error_code','error_param']},'usage':m.usage()}),flush=True)
   if result['status']=='VALID':break
   transient=(result.get('exception_type') in {'APITimeoutError','APIConnectionError','InternalServerError'} or (result.get('http_status') or 0)>=500)
   if not transient or attempt==2:raise SystemExit(2)
   target=m.OUT/'episodes'/(job['id']+'.json')
   history=root/'transport-attempts'/os.environ['ADOM_AGENTDOJO_SUITE']/job['id']/str(attempt);history.mkdir(parents=True)
   shutil.move(target,history/'episode.json')
   trace_root=m.OUT/'logs'/phase/f'r1-{condition}'
   for trace in trace_root.glob(f"*/{os.environ['ADOM_AGENTDOJO_SUITE']}/{task}/{job.get('attack') or 'none'}/{inj or 'none'}.json"):
    shutil.copy2(trace,history/'native-trace.json')
   time.sleep(5)

print(os.environ['ADOM_AGENTDOJO_SUITE'],phase,condition,'COMPLETE',flush=True)
